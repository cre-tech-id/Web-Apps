@extends('layout.base.base')

@section('content')
<div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                <div class="row">
                  <div class="col-lg-12">
                    <h6>Web Kesenian Tradisional</h6>
                    <h2>Welcome!</h2>
                    <p>Hi!, ini adalah website untuk mewadahi pengguna dalam mencari dan menyewa berbagai dari kesenian yang ada, serta menjadi wadah bagi 
                        para seniman tradisional dalam mempromosikan atau mencari penyewa jasa secara digital.

                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                <!-- <img src="assets/images/slider-dec.png" alt=""> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
