<?php $__env->startSection('content'); ?>

<section class="min-vh-100 mb-8">
    <div class="page-header align-items-start min-vh-50 pt-5 pb-11 mx-3 border-radius-lg"
        style="background-image: url('../assets/img/logins.png');">
        <span class="mask bg-gradient-dark opacity-6"></span>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 text-center mx-auto">
                    <h1 class="text-white mb-2 mt-5">Silahkan Daftarkan Akun Anda</h1>
                    <!-- <p class="text-lead text-white">Use these awesome forms to login or create new account in your
                        project for free.</p> -->
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row mt-lg-n10 mt-md-n11 mt-n10">
            <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
                <div class="card z-index-0">

                    <div class="card-body">
                        <form role="form text-left" method="POST" action="/register" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="gambar">Nama</label>
                                <input type="text" class="form-control" placeholder="Nama" name="nama" id="nama"
                                    aria-label="Name" aria-describedby="username" value="<?php echo e(old('nama')); ?>">
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="gambar">Email</label>
                                <input type="email" class="form-control" placeholder="Email" name="email" id="email"
                                    aria-label="Email" aria-describedby="email-addon" value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="gambar">Password</label>
                                <input type="password" class="form-control" placeholder="Password" name="password"
                                    id="password" aria-label="Password" aria-describedby="password-addon">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="gambar">Alamat</label>
                                <?php echo Form::select('kota', $kota, '$kota', [
                                'class' => 'form-control',
                                'placeholder' => 'Pilih Kota',
                                'id' => 'kota_id'
                                ]); ?>

                                <div class="" id="kec"></div>
                                <div class="" id="desa"></div>
                                <br>
                                <input type="text" class="form-control" placeholder="Masukan Detail Alamat" name="jl" id="jl">
                                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="gambar">No Hp</label>
                                <input type="text" class="form-control" placeholder="No Hp" name="no_hp" id="no" value="<?php echo e(old('no_hp')); ?>">
                                <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="desc">Deskripsi</label><br>
                                
                                <textarea name="desc" id="desc" cols="31" rows="10" value="<?php echo e(old('desc')); ?>"></textarea>
                                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-xs mt-2"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3" hidden>
                                <input type="text" class="form-control" value="2" name="role_id" id="role_id">
                            </div>
                            <div>
                                <label for="gambar">Foto Profil</label>
                                <input class="form-control" type="file" id="gambar" name="gambar">
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn bg-gradient-dark w-100 my-4 mb-2">Sign up</button>
                            </div>
                            <p class="text-sm mt-3 mb-0">Already have an account? <a href="login"
                                    class="text-dark font-weight-bolder">Sign in</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<script>
        $(document).ready(function() {
            $('body').on('change', '#kota_id', function() {
                let id = $(this).val();
                let route = "<?php echo e($route_get_kecamatan); ?>";
                $.ajax({
                    type: 'get',
                    url: route,
                    data: {
                        kota_id: id
                    },
                    success: function(data) {
                        $('#kec').html(data);
                    }
                })
            })
        })

        $('body').on('change', '#kecamatan_id', function() {
                let id = $(this).val();
                let route = "<?php echo e($route_get_desa); ?>";
                $.ajax({
                    type: 'get',
                    url: route,
                    data: {
                        kecamatan_id: id
                    },
                    success: function(data) {
                        $('#desa').html(data);
                    }
                })
            })
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/backup velda/laravel-velda/resources/views/session/register.blade.php ENDPATH**/ ?>