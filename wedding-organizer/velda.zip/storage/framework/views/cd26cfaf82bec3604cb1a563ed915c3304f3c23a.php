<div class="mt-4" >
<?php echo Form::select('desa_id', $desa, '', [
    'class' => 'form-control',
    'placeholder' => 'Pilih Desa',
    'id' => 'desa_id',
]); ?>

</div><?php /**PATH /home/jundix/Downloads/backup velda/laravel-velda/resources/views/session/list_desa.blade.php ENDPATH**/ ?>