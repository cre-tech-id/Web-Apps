<footer class="sticky-footer">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-start">
                    Copyright © <script>
                    document.write(new Date().getFullYear())
                    </script>
                    <a style="color: #252f40;" href="#" class="font-weight-bold ml-1">Cretech</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/jundix/Downloads/backup velda/laravel-velda/resources/views/layouts/footers/auth/footer.blade.php ENDPATH**/ ?>