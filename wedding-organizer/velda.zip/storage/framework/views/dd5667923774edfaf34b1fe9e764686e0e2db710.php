<?php $__env->startSection('content'); ?>

<div>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4 mx-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Data User</h5>
                        </div>
                        <?php if(Session::get('role')==2): ?>
                        <a href="<?php echo e(route('tambah_user')); ?>" class="btn bg-gradient-primary btn-sm mb-0" type="button">+&nbsp; New User</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-4">
                                        Nama
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        Alamat
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        No Hp
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="ps-4">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($u->nama); ?></p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($u->alamat); ?></p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($u->no_hp); ?></p>
                                    </td>
                                    <td class="text-center">
                                        <?php if(Session::get('role')==1): ?>
                                        <a href="/user/hapus/<?php echo e($u->id); ?>" class="" data-bs-toggle="tooltip" data-bs-original-title="Delete user">
                                            <i class="cursor-pointer fas fa-trash text-secondary"></i>
                                        </a>
                                        </span>
                                        <?php else: ?>
                                        <a href="/user/edit/<?php echo e($u->id); ?>" class="mx-3" data-bs-toggle="tooltip" data-bs-original-title="Edit user">
                                            <i class="fas fa-user-edit text-secondary"></i>
                                        </a>
                                        <span>
                                        <a href="/user/hapus/<?php echo e($u->id); ?>" class="" data-bs-toggle="tooltip" data-bs-original-title="Delete user">
                                            <i class="cursor-pointer fas fa-trash text-secondary"></i>
                                        </a>
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/backup velda/laravel-velda/resources/views/user/data_user.blade.php ENDPATH**/ ?>