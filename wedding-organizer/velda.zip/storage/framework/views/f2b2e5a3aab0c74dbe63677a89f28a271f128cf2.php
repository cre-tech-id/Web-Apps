<?php $__env->startSection('content'); ?>

<div>
    <div class="row">
        <div class="col-12">
            <div class="card mb-4 mx-4">
                <div class="card-header pb-0">
                    <div class="d-flex flex-row justify-content-between">
                        <div>
                            <h5 class="mb-0">Komentar</h5>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="mt-4" style="width:100%">
                            <thead>
                                <tr>
                                    <th style="width:15%;" class="text-uppercase text-secondary text-xs font-weight-bolder opacity-7 ps-4">
                                        User
                                    </th>
                                    <th style="width:15%;" class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        Paket
                                    </th>
                                    <?php if(Session::get('role')==1): ?>
                                    <th style="width:15%;" class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        Penyedia
                                    </th>
                                    <?php endif; ?>
                                    <th style="width:20%;" class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        Komentar
                                    </th>
                                    <?php if(Session::get('role')==1): ?>
                                    <th class="text-center text-uppercase text-secondary text-xs font-weight-bolder opacity-7">
                                        Action
                                    </th>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td><hr></td>
                                    <td><hr></td>
                                    <td><hr></td>
                                    <?php if(Session::get('role')==1): ?>
                                    <td><hr></td>
                                    <td><hr></td>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="ps-4">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($k->nama_user); ?></p>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($k->nama_paket); ?></p>
                                    </td>
                                    <?php if(Session::get('role')==1): ?>
                                    <td class="text-center">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($k->nama_penyedia); ?></p>
                                    </td>
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <p class="text-l font-weight-bold mb-0"><?php echo e($k->komentar); ?></p>
                                    </td>
                                    <?php if(Session::get('role')==1): ?>
                                    <td class="text-center">
                                        <span>
                                        <a href="/komentar/hapus/<?php echo e($k->id); ?>" class="" data-bs-toggle="tooltip" >
                                            <i class="cursor-pointer fas fa-trash text-secondary"></i>
                                        </a>
                                        </span>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <td><hr></td>
                                    <td><hr></td>
                                    <td><hr></td>
                                    <?php if(Session::get('role')==1): ?>
                                    <td><hr></td>
                                    <td><hr></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jundix/Downloads/backup velda/laravel-velda/resources/views/komentar/komentar.blade.php ENDPATH**/ ?>