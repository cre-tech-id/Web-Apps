<div class="mt-4" >
<?php echo Form::select('kecamatan_id', $kecamatan, '', [
    'class' => 'form-control',
    'placeholder' => 'Pilih Kecamatan',
    'id' => 'kecamatan_id',
]); ?>

<div><?php /**PATH /home/jundix/Downloads/backup velda/laravel-velda/resources/views/session/list_kecamatan.blade.php ENDPATH**/ ?>