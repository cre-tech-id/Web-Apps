<div class="mt-4" >
{!! Form::select('desa_id', $desa, '', [
    'class' => 'form-control',
    'placeholder' => 'Pilih Desa',
    'id' => 'desa_id',
]) !!}
</div>